<?php
// Database connection configuration
$servername = "localhost";
$username = "root"; 
$password = "root"; // Default password for MAMP is 'root'. Use "" for XAMPP.
$dbname = "internship_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// If no error, the connection is successful
?>