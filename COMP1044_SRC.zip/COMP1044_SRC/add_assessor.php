<?php
session_start();
include 'db_config.php';

// Security Check: Only Admin can access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: login.php");
    exit();
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST['full_name']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($full_name) || empty($username) || empty($password)) {
        $error = "All fields are required.";
    } else {
        // Check if username already exists
        $check_stmt = $conn->prepare("SELECT user_id FROM `User` WHERE username = ?");
        if (!$check_stmt) {
            die("Failed to prepare username check.");
        }

        $check_stmt->bind_param("s", $username);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            $error = "Username already exists.";
        } else {
            // Insert into User table
            $user_stmt = $conn->prepare("INSERT INTO `User` (username, password_hash, role) VALUES (?, ?, 'ASSESSOR')");
            if (!$user_stmt) {
                die("Failed to prepare user insert.");
            }

            $user_stmt->bind_param("ss", $username, $password);

            if ($user_stmt->execute()) {
                $user_id = $conn->insert_id;

                // Insert into Assessor table
                $assessor_stmt = $conn->prepare("INSERT INTO Assessor (user_id, full_name) VALUES (?, ?)");
                if (!$assessor_stmt) {
                    die("Failed to prepare assessor insert.");
                }

                $assessor_stmt->bind_param("is", $user_id, $full_name);

                if ($assessor_stmt->execute()) {
                    header("Location: manage_assessors.php");
                    exit();
                } else {
                    $error = "Failed to create assessor profile.";
                }

                $assessor_stmt->close();
            } else {
                $error = "Failed to create assessor account.";
            }

            $user_stmt->close();
        }

        $check_stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Assessor - Internship Management System</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; padding: 40px; background: #f4f7f6; }
        .form-container { background: white; padding: 25px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); max-width: 450px; margin: auto; }
        h2 { color: #333; margin-bottom: 20px; text-align: center; }
        label { font-weight: bold; color: #555; display: block; margin-top: 10px; }
        input { width: 100%; padding: 12px; margin: 8px 0 18px 0; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; font-size: 14px; }
        .btn-save { background: #28a745; color: white; border: none; padding: 12px 25px; cursor: pointer; border-radius: 5px; font-size: 16px; width: 100%; transition: background 0.3s; }
        .btn-save:hover { background: #218838; }
        .btn-back { display: block; text-align: center; color: #007bff; text-decoration: none; margin-top: 15px; font-size: 14px; }
        .btn-back:hover { text-decoration: underline; }
        .error-msg { color: #d9534f; background: #f2dede; padding: 10px; border-radius: 5px; margin-bottom: 15px; font-size: 14px; border: 1px solid #ebccd1; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Add New Assessor Account</h2>

    <?php if (!empty($error)) echo "<div class='error-msg'>" . htmlspecialchars($error) . "</div>"; ?>

    <form method="POST">
        <label>Full Name:</label>
        <input type="text" name="full_name" placeholder="Enter assessor full name" required>

        <label>Username:</label>
        <input type="text" name="username" placeholder="Enter login username" required>

        <label>Password:</label>
        <input type="password" name="password" placeholder="Enter login password" required>

        <button type="submit" class="btn-save">Create Assessor Account</button>
        <a href="manage_assessors.php" class="btn-back">Cancel & Go Back</a>
    </form>
</div>

</body>
</html>