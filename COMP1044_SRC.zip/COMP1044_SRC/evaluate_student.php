<?php
session_start();
include 'db_config.php';

// Security Check: Only Assessor can access this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ASSESSOR') {
    header("Location: login.php");
    exit();
}

// Check if internship_id is provided in the URL
if (!isset($_GET['internship_id'])) {
    header("Location: assessor_dashboard.php");
    exit();
}

$internship_id = (int) $_GET['internship_id'];
$user_id = $_SESSION['user_id'];

// Verify that this internship belongs to the currently logged-in assessor
$verify_sql = "SELECT i.internship_id, s.student_name, i.company_name
               FROM Internship i
               JOIN Student s ON i.student_id = s.student_id
               JOIN Assessor a ON i.assessor_id = a.assessor_id
               WHERE i.internship_id = ? AND a.user_id = ?";

$verify_stmt = $conn->prepare($verify_sql);

if (!$verify_stmt) {
    die("Failed to prepare verification query.");
}

$verify_stmt->bind_param("ii", $internship_id, $user_id);
$verify_stmt->execute();
$verify_result = $verify_stmt->get_result();

if ($verify_result->num_rows === 0) {
    die("Error: You are not authorized to evaluate this internship record.");
}

$internship_data = $verify_result->fetch_assoc();

// Fetch the 8 fixed assessment criteria and their weights
$criteria = $conn->query("SELECT * FROM AssessmentCriterion");

if (!$criteria) {
    die("Failed to load assessment criteria.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $comments = $_POST['comments'];
    $marks = $_POST['marks']; // This is an array of raw scores (0-100)

    // 1. Create a primary Assessment record
    $stmt = $conn->prepare("INSERT INTO Assessment (internship_id, qualitative_comments) VALUES (?, ?)");
    
    if (!$stmt) {
        die("Failed to prepare assessment insert.");
    }

    $stmt->bind_param("is", $internship_id, $comments);
    $stmt->execute();
    $assessment_id = $conn->insert_id;

    $total_weighted_score = 0;

    // 2. Loop through each criterion to save scores and calculate the weighted total
    foreach ($marks as $criterion_id => $score) {
        // Fetch the weight percentage for this specific criterion
        $res = $conn->query("SELECT weight_percent FROM AssessmentCriterion WHERE criterion_id = $criterion_id");
        $c_data = $res->fetch_assoc();
        $weight = $c_data['weight_percent'];

        // Core Calculation: (Raw Score * Weight) / 100
        $total_weighted_score += ($score * $weight) / 100;

        // Insert individual marks into the AssessmentMark table
        $conn->query("INSERT INTO AssessmentMark (assessment_id, criterion_id, score) VALUES ($assessment_id, $criterion_id, $score)");
    }

    // 3. Update the final weighted score in the Assessment table
    $update_stmt = $conn->prepare("UPDATE Assessment SET final_score = ? WHERE assessment_id = ?");
    
    if (!$update_stmt) {
        die("Failed to prepare score update.");
    }

    $update_stmt->bind_param("di", $total_weighted_score, $assessment_id);
    $update_stmt->execute();

    echo "<script>alert('Evaluation completed! Final Weighted Score: $total_weighted_score'); window.location.href='assessor_dashboard.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Evaluate Student - Internship System</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 30px; background-color: #f8f9fa; line-height: 1.6; }
        .container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); max-width: 700px; margin: auto; }
        h2 { border-bottom: 2px solid #007bff; padding-bottom: 10px; color: #333; }
        .student-info { background: #eef4ff; padding: 12px 15px; border-radius: 6px; margin-bottom: 20px; color: #333; }
        .criterion-item { margin-bottom: 20px; padding: 15px; border: 1px solid #eee; border-radius: 5px; }
        .criterion-name { font-weight: bold; color: #0056b3; display: block; margin-bottom: 5px; }
        .weight-tag { font-size: 0.85em; color: #666; background: #e9ecef; padding: 2px 8px; border-radius: 10px; }
        input[type="number"] { width: 80px; padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        textarea { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .btn-submit { background-color: #007bff; color: white; border: none; padding: 12px 24px; border-radius: 4px; cursor: pointer; font-size: 16px; transition: 0.3s; }
        .btn-submit:hover { background-color: #0056b3; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Internship Performance Evaluation (0-100 Scale)</h2>

        <div class="student-info">
            <strong>Student:</strong> <?php echo htmlspecialchars($internship_data['student_name']); ?><br>
            <strong>Company:</strong> <?php echo htmlspecialchars($internship_data['company_name']); ?>
        </div>

        <form method="POST">
            <?php while($c = $criteria->fetch_assoc()): ?>
                <div class="criterion-item">
                    <span class="criterion-name"><?php echo htmlspecialchars($c['criterion_name']); ?></span>
                    <span class="weight-tag">Weight: <?php echo htmlspecialchars($c['weight_percent']); ?>%</span>
                    <p>Score: <input type="number" name="marks[<?php echo $c['criterion_id']; ?>]" min="0" max="100" required></p>
                </div>
            <?php endwhile; ?>
            
            <p><strong>Qualitative Comments:</strong><br>
            <textarea name="comments" rows="5" placeholder="Provide detailed feedback regarding the student's performance..." required></textarea></p>
            
            <button type="submit" class="btn-submit">Submit Assessment</button>
            <a href="assessor_dashboard.php" style="margin-left: 15px; color: #666; text-decoration: none;">Cancel</a>
        </form>
    </div>
</body>
</html>