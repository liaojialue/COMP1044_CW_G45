<?php
session_start();
include 'db_config.php';

// Security Check: Ensure only Assessor can access this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ASSESSOR') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch the list of interns assigned to the currently logged-in assessor
$sql = "SELECT i.internship_id, s.student_name, i.company_name 
        FROM Internship i 
        JOIN Student s ON i.student_id = s.student_id 
        JOIN Assessor a ON i.assessor_id = a.assessor_id 
        WHERE a.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assessor Dashboard - Internship System</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 25px; background-color: #f4f4f9; }
        h2 { color: #333; }
        h3 { color: #555; margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; background: white; margin-top: 15px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #007bff; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .btn-eval { color: #007bff; text-decoration: none; font-weight: bold; }
        .btn-eval:hover { color: #0056b3; text-decoration: underline; }
        .logout-link { display: inline-block; margin-top: 20px; color: #d9534f; text-decoration: none; }
    </style>
</head>
<body>
    <h2>Welcome, Assessor</h2>
    <h3>Pending Internship Evaluations</h3>
    
    <table>
        <thead>
            <tr>
                <th>Student Name</th>
                <th>Internship Company</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                <td><?php echo htmlspecialchars($row['company_name']); ?></td>
                <td><a href="evaluate_student.php?internship_id=<?php echo urlencode($row['internship_id']); ?>" class="btn-eval">Start Evaluation</a></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    
    <br>
    <a href="logout.php" class="logout-link">Logout</a>
</body>
</html>