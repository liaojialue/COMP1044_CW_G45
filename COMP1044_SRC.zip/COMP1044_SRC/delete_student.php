<?php
session_start();
include 'db_config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("Error: No student selected.");
}

$student_id = $_GET['id'];

$conn->begin_transaction();

try {
    // 1. Find all internship IDs for this student
    $sql0 = "SELECT internship_id FROM Internship WHERE student_id = ?";
    $stmt0 = $conn->prepare($sql0);
    $stmt0->bind_param("s", $student_id);
    $stmt0->execute();
    $result0 = $stmt0->get_result();

    $internship_ids = [];
    while ($row = $result0->fetch_assoc()) {
        $internship_ids[] = $row['internship_id'];
    }

    // 2. For each internship, find assessment IDs
    $assessment_ids = [];
    if (!empty($internship_ids)) {
        $sql1 = "SELECT assessment_id FROM Assessment WHERE internship_id = ?";
        $stmt1 = $conn->prepare($sql1);

        foreach ($internship_ids as $internship_id) {
            $stmt1->bind_param("i", $internship_id);
            $stmt1->execute();
            $result1 = $stmt1->get_result();

            while ($row = $result1->fetch_assoc()) {
                $assessment_ids[] = $row['assessment_id'];
            }
        }
    }

    // 3. Delete AssessmentMark records first
    if (!empty($assessment_ids)) {
        $sql2 = "DELETE FROM AssessmentMark WHERE assessment_id = ?";
        $stmt2 = $conn->prepare($sql2);

        foreach ($assessment_ids as $assessment_id) {
            $stmt2->bind_param("i", $assessment_id);
            $stmt2->execute();
        }
    }

    // 4. Delete Assessment records
    if (!empty($internship_ids)) {
        $sql3 = "DELETE FROM Assessment WHERE internship_id = ?";
        $stmt3 = $conn->prepare($sql3);

        foreach ($internship_ids as $internship_id) {
            $stmt3->bind_param("i", $internship_id);
            $stmt3->execute();
        }
    }

    // 5. Delete Internship records
    $sql4 = "DELETE FROM Internship WHERE student_id = ?";
    $stmt4 = $conn->prepare($sql4);
    $stmt4->bind_param("s", $student_id);
    $stmt4->execute();

    // 6. Delete Student record
    $sql5 = "DELETE FROM Student WHERE student_id = ?";
    $stmt5 = $conn->prepare($sql5);
    $stmt5->bind_param("s", $student_id);
    $stmt5->execute();

    $conn->commit();

    header("Location: admin_dashboard.php");
    exit();
} catch (Exception $e) {
    $conn->rollback();
    die("Error deleting student record: " . $e->getMessage());
}
?>