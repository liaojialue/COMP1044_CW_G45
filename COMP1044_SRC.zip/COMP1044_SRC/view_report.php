<?php
session_start();
include 'db_config.php'; // Database connection

// Security Check: Must be logged in
if (!isset($_SESSION['role']) || !isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if internship ID is provided
if (!isset($_GET['internship_id'])) {
    die("Error: No assessment record selected.");
}

$internship_id = (int) $_GET['internship_id'];
$user_role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Admin can view all reports
if ($user_role === 'ADMIN') {
    $sql = "SELECT s.student_name, s.programme, i.company_name, a.final_score, a.qualitative_comments 
            FROM Internship i
            JOIN Student s ON i.student_id = s.student_id
            JOIN Assessment a ON i.internship_id = a.internship_id
            WHERE i.internship_id = ?";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Failed to prepare query.");
    }

    $stmt->bind_param("i", $internship_id);
}

// Assessor can only view reports of their own assigned students
elseif ($user_role === 'ASSESSOR') {
    $sql = "SELECT s.student_name, s.programme, i.company_name, a.final_score, a.qualitative_comments 
            FROM Internship i
            JOIN Student s ON i.student_id = s.student_id
            JOIN Assessment a ON i.internship_id = a.internship_id
            JOIN Assessor assr ON i.assessor_id = assr.assessor_id
            WHERE i.internship_id = ? AND assr.user_id = ?";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Failed to prepare query.");
    }

    $stmt->bind_param("ii", $internship_id, $user_id);
}

// Other roles are not allowed
else {
    die("Error: Unauthorized access.");
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Error: No evaluation report found for this record or you do not have permission to view it.");
}

$data = $result->fetch_assoc();

// Set back page based on role
$back_page = ($user_role === 'ADMIN') ? 'admin_dashboard.php' : 'assessor_dashboard.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Evaluation Report - <?php echo htmlspecialchars($data['student_name']); ?></title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f0f2f5; padding: 20px; }
        .report-card { 
            background: white; 
            border: 1px solid #ddd; 
            padding: 40px; 
            width: 700px; 
            margin: 30px auto; 
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            border-radius: 8px;
        }
        h1 { color: #333; text-align: center; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
        .info-section { margin: 20px 0; font-size: 16px; line-height: 1.8; }
        .score-box { 
            text-align: center; 
            background: #f8f9fa; 
            padding: 20px; 
            border-radius: 5px; 
            margin: 20px 0;
            border-left: 5px solid #d9534f;
        }
        .score { font-size: 32px; color: #d9534f; font-weight: bold; }
        .comments { font-style: italic; color: #555; background: #fffdf5; padding: 15px; border: 1px dashed #ccc; }
        .no-print { margin-top: 30px; text-align: center; }
        .btn { padding: 10px 20px; text-decoration: none; border-radius: 4px; cursor: pointer; border: none; }
        .btn-print { background: #28a745; color: white; margin-right: 10px; }
        .btn-back { background: #6c757d; color: white; }
        
        @media print {
            .no-print { display: none; }
            body { background: white; padding: 0; }
            .report-card { border: none; box-shadow: none; width: 100%; margin: 0; }
        }
    </style>
</head>
<body>
    <div class="report-card">
        <h1>Internship Evaluation Report</h1>
        
        <div class="info-section">
            <p><strong>Student Name:</strong> <?php echo htmlspecialchars($data['student_name']); ?></p>
            <p><strong>Academic Programme:</strong> <?php echo htmlspecialchars($data['programme']); ?></p>
            <p><strong>Internship Organization:</strong> <?php echo htmlspecialchars($data['company_name']); ?></p>
        </div>

        <div class="score-box">
            <h3>Final Weighted Score</h3>
            <span class="score"><?php echo number_format($data['final_score'], 2); ?> / 100.00</span>
        </div>

        <div class="info-section">
            <p><strong>Assessor's Qualitative Comments:</strong></p>
            <div class="comments">
                <?php echo nl2br(htmlspecialchars($data['qualitative_comments'])); ?>
            </div>
        </div>

        <div class="no-print">
            <button onclick="window.print()" class="btn btn-print">Print Report</button>
            <a href="<?php echo $back_page; ?>" class="btn btn-back">Back to Dashboard</a>
        </div>
    </div>
</body>
</html>