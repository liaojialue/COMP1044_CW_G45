<?php
session_start();
include 'db_config.php';

// Security Check: Only Admin can access this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: login.php");
    exit();
}

// Get search keyword
$search = isset($_GET['search']) ? trim($_GET['search']) : "";

// Base SQL query
$sql = "SELECT s.student_id, s.student_name, s.programme, i.internship_id
        FROM Student s
        LEFT JOIN Internship i ON s.student_id = i.student_id";

// If search keyword exists, filter by student_id or student_name
if (!empty($search)) {
    $sql .= " WHERE s.student_id LIKE ? OR s.student_name LIKE ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Failed to prepare search query.");
    }

    $search_param = "%" . $search . "%";
    $stmt->bind_param("ss", $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($sql);

    if (!$result) {
        die("Failed to fetch student records.");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Internship Management System</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f8f9fa; }
        .header { display: flex; justify-content: space-between; align-items: center; background: #333; color: white; padding: 15px 25px; border-radius: 5px; }
        h3 { color: #444; margin-top: 30px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: white; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #f2f2f2; color: #333; }
        .btn { padding: 8px 15px; background: #28a745; color: white; text-decoration: none; border-radius: 4px; display: inline-block; font-size: 14px; }
        .btn-assign { background: #007bff; margin-top: 10px; }
        .action-link { text-decoration: none; color: #007bff; font-size: 14px; }
        .action-link:hover { text-decoration: underline; }
        .report-link { color: #28a745; font-weight: bold; }
        .no-data { text-align: center; color: #666; }
        .no-report { color: #999; font-size: 14px; }

        .search-box {
            margin-top: 20px;
            background: white;
            padding: 15px;
            border-radius: 6px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.08);
        }

        .search-box input[type="text"] {
            width: 280px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .search-btn {
            padding: 10px 16px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .reset-btn {
            padding: 10px 16px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-left: 8px;
            display: inline-block;
        }
    </style>
</head>
<body>

<div class="header">
    <h2>Admin Main Panel</h2>
    <a href="logout.php" style="color: white; text-decoration: none;">Logout</a>
</div>

<h3>Student Records Management</h3>
<p>In this section, you can add new students, update their details, remove records, and search for specific students.</p>

<div class="search-box">
    <form method="GET">
        <input type="text" name="search" placeholder="Search by Student ID or Name" value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit" class="search-btn">Search</button>
        <a href="admin_dashboard.php" class="reset-btn">Reset</a>
    </form>
</div>

<table>
    <thead>
        <tr>
            <th>Student ID</th>
            <th>Name</th>
            <th>Programme</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                <td><?php echo htmlspecialchars($row['programme']); ?></td>
                <td>
                    <a href="edit_student.php?id=<?php echo urlencode($row['student_id']); ?>" class="action-link">Edit</a> | 
                    <a href="delete_student.php?id=<?php echo urlencode($row['student_id']); ?>" class="action-link" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a> |
                    
                    <?php if (!empty($row['internship_id'])): ?>
                        <a href="view_report.php?internship_id=<?php echo urlencode($row['internship_id']); ?>" class="action-link report-link">View Report</a>
                    <?php else: ?>
                        <span class="no-report">No Report</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4" class="no-data">No matching student records found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<br>
<a href="add_student.php" class="btn">+ Add New Student</a>
<br>
<a href="assign_internship.php" class="btn btn-assign">+ Assign Internship Unit</a>
<br><br>
<a href="manage_assessors.php" class="btn" style="background:#17a2b8;">+ Manage Assessor Accounts</a>

</body>
</html>