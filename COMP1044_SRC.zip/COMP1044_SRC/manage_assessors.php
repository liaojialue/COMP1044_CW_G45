<?php
session_start();
include 'db_config.php';

// Security Check: Only Admin can access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: login.php");
    exit();
}

// Handle delete request
if (isset($_GET['delete_assessor_id']) && isset($_GET['delete_user_id'])) {
    $assessor_id = (int) $_GET['delete_assessor_id'];
    $user_id = (int) $_GET['delete_user_id'];

    // Delete assessor record first
    $stmt1 = $conn->prepare("DELETE FROM Assessor WHERE assessor_id = ?");
    if ($stmt1) {
        $stmt1->bind_param("i", $assessor_id);
        $stmt1->execute();
        $stmt1->close();
    }

    // Then delete linked user account
    $stmt2 = $conn->prepare("DELETE FROM `User` WHERE user_id = ? AND role = 'ASSESSOR'");
    if ($stmt2) {
        $stmt2->bind_param("i", $user_id);
        $stmt2->execute();
        $stmt2->close();
    }

    header("Location: manage_assessors.php");
    exit();
}

// Fetch assessor accounts
$sql = "SELECT a.assessor_id, a.full_name, a.user_id, u.username
        FROM Assessor a
        JOIN `User` u ON a.user_id = u.user_id
        ORDER BY a.assessor_id ASC";

$result = $conn->query($sql);

if (!$result) {
    die("Failed to fetch assessor records.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Assessors - Internship Management System</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f8f9fa; }
        .header { display: flex; justify-content: space-between; align-items: center; background: #333; color: white; padding: 15px 25px; border-radius: 5px; }
        h3 { color: #444; margin-top: 30px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: white; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #f2f2f2; color: #333; }
        .btn { padding: 8px 15px; background: #28a745; color: white; text-decoration: none; border-radius: 4px; display: inline-block; font-size: 14px; }
        .btn-back { background: #6c757d; margin-left: 10px; }
        .action-link { text-decoration: none; color: #dc3545; font-size: 14px; }
        .action-link:hover { text-decoration: underline; }
        .no-data { text-align: center; color: #666; }
    </style>
</head>
<body>

<div class="header">
    <h2>Manage Assessor Accounts</h2>
    <a href="logout.php" style="color: white; text-decoration: none;">Logout</a>
</div>

<h3>Assessor Account List</h3>
<p>Admin can create and manage assessor accounts in this section.</p>

<table>
    <thead>
        <tr>
            <th>Assessor ID</th>
            <th>Full Name</th>
            <th>Username</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['assessor_id']); ?></td>
                <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                <td><?php echo htmlspecialchars($row['username']); ?></td>
                <td>
                    <a href="manage_assessors.php?delete_assessor_id=<?php echo urlencode($row['assessor_id']); ?>&delete_user_id=<?php echo urlencode($row['user_id']); ?>"
                       class="action-link"
                       onclick="return confirm('Are you sure you want to delete this assessor account?')">
                       Delete
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4" class="no-data">No assessor accounts found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<br>
<a href="add_assessor.php" class="btn">+ Add New Assessor</a>
<a href="admin_dashboard.php" class="btn btn-back">Back to Dashboard</a>

</body>
</html>