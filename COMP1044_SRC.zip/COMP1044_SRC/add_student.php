<?php
session_start();
include 'db_config.php';

// Security Check: Only Admin can access this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student_id'];
    $student_name = $_POST['student_name'];
    $programme = $_POST['programme'];

    // Insert data into Student table
    $sql = "INSERT INTO Student (student_id, student_name, programme) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $student_id, $student_name, $programme);

    if ($stmt->execute()) {
        // Redirect back to Admin Dashboard after successful insertion
        header("Location: admin_dashboard.php"); 
        exit();
    } else {
        $error = "Failed to add student. Student ID might already exist.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Student - Internship Management System</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; padding: 40px; background: #f4f7f6; }
        .form-container { background: white; padding: 25px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); max-width: 450px; margin: auto; }
        h2 { color: #333; margin-bottom: 20px; text-align: center; }
        label { font-weight: bold; color: #555; display: block; margin-top: 10px; }
        input { width: 100%; padding: 12px; margin: 8px 0 18px 0; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; font-size: 14px; }
        .btn-save { background: #28a745; color: white; border: none; padding: 12px 25px; cursor: pointer; border-radius: 5px; font-size: 16px; width: 100%; transition: background 0.3s; }
        .btn-save:hover { background: #218838; }
        .btn-back { display: block; text-align: center; color: #007bff; text-decoration: none; margin-top: 15px; font-size: 14px; }
        .btn-back:hover { text-decoration: underline; }
        .error-msg { color: #d9534f; background: #f2dede; padding: 10px; border-radius: 5px; margin-bottom: 15px; font-size: 14px; border: 1px solid #ebccd1; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Add New Student Profile</h2>
    
    <?php if(isset($error)) echo "<div class='error-msg'>$error</div>"; ?>
    
    <form method="POST">
        <label>Student ID:</label>
        <input type="text" name="student_id" placeholder="e.g., 20441234" required>
        
        <label>Full Name:</label>
        <input type="text" name="student_name" placeholder="Enter student's full name" required>
        
        <label>Programme:</label>
        <input type="text" name="programme" placeholder="e.g., BSc Computer Science" required>
        
        <button type="submit" class="btn-save">Save Profile</button>
        <a href="admin_dashboard.php" class="btn-back">Cancel & Go Back</a>
    </form>
</div>

</body>
</html>