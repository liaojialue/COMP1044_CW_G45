<?php
session_start();
include 'db_config.php';

// Security Check: Only Admin can access this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: login.php");
    exit();
}

// Check if student ID is provided
if (!isset($_GET['id'])) {
    die("Error: No student selected.");
}

$student_id = $_GET['id'];

// Update student record when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_name = trim($_POST['student_name']);
    $programme = trim($_POST['programme']);

    $sql = "UPDATE Student SET student_name = ?, programme = ? WHERE student_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $student_name, $programme, $student_id);

    if ($stmt->execute()) {
        header("Location: admin_dashboard.php");
        exit();
    } else {
        die("Error updating student record.");
    }
}

// Fetch current student data
$sql = "SELECT * FROM Student WHERE student_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Student not found.");
}

$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Student</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f8f9fa; }
        .form-box {
            width: 400px;
            background: white;
            padding: 20px;
            border-radius: 6px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .btn {
            padding: 10px 16px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .back-link {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: #007bff;
        }
    </style>
</head>
<body>

<h2>Edit Student Record</h2>

<div class="form-box">
    <form method="POST">
        <label>Student ID</label>
        <input type="text" value="<?php echo htmlspecialchars($row['student_id']); ?>" readonly>

        <label>Student Name</label>
        <input type="text" name="student_name" value="<?php echo htmlspecialchars($row['student_name']); ?>" required>

        <label>Programme</label>
        <input type="text" name="programme" value="<?php echo htmlspecialchars($row['programme']); ?>" required>

        <button type="submit" class="btn">Update</button>
    </form>

    <a href="admin_dashboard.php" class="back-link">← Back to Dashboard</a>
</div>

</body>
</html>