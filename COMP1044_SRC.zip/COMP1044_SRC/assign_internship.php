<?php
session_start();
include 'db_config.php';

// Security Check: Only Admin can access this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: login.php");
    exit();
}

// Fetch student and assessor records for the dropdown menus
$students = $conn->query("SELECT * FROM Student");
$assessors = $conn->query("SELECT * FROM Assessor");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sid = $_POST['student_id'];
    $aid = $_POST['assessor_id'];
    $company = $_POST['company_name'];

    // Insert the assignment details into the Internship table
    $sql = "INSERT INTO Internship (student_id, assessor_id, company_name) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sis", $sid, $aid, $company);

    if ($stmt->execute()) {
        echo "<script>alert('Assignment successful!'); window.location.href='admin_dashboard.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assign Internship - Management System</title>
</head>
<body style="font-family: Arial, sans-serif; padding: 30px; background-color: #f4f7f6;">
    <h2 style="color: #333;">Assign Internship Unit & Assessor</h2>
    
    <form method="POST" style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); display: inline-block; min-width: 400px;">
        <p>
            <label style="font-weight: bold;">Select Student:</label><br>
            <select name="student_id" style="width: 100%; padding: 10px; margin-top: 5px;">
                <?php while($s = $students->fetch_assoc()) echo "<option value='".$s['student_id']."'>".$s['student_name']."</option>"; ?>
            </select>
        </p>

        <p>
            <label style="font-weight: bold;">Select Assessor:</label><br>
            <select name="assessor_id" style="width: 100%; padding: 10px; margin-top: 5px;">
                <?php while($a = $assessors->fetch_assoc()) echo "<option value='".$a['assessor_id']."'>".$a['full_name']."</option>"; ?>
            </select>
        </p>

        <p>
            <label style="font-weight: bold;">Company Name:</label><br>
            <input type="text" name="company_name" placeholder="e.g. Google, Intel" required style="width: 100%; padding: 10px; margin-top: 5px; box-sizing: border-box;">
        </p>
        
        <br>
        <button type="submit" style="padding: 12px 25px; background-color: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px;">Confirm Assignment</button>
        <a href="admin_dashboard.php" style="margin-left: 15px; color: #666; text-decoration: none; font-size: 14px;">Back to Dashboard</a>
    </form>
</body>
</html>